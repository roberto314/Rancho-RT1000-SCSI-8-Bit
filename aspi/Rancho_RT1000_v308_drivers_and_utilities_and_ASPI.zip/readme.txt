!ran10c0.cfg............RT1000C board configuration for plug and play 
			systems.
!ran1ab0.cfg............RT1000A/B board configuration for plug and play 
			systems.
1kc.exe.................Self-extracting zip of RT1000C product diskette 
			version 1.03.
1kos2.exe...............OS/2 version 2.0 driver for
			RT1000.
308.exe.................Self-extracting zip of RT1000A/B/MC product 
			diskette V3.08.
@708d.adf...............Configuration file for micro channel machines.
crlscsi.ugm.............CorelSCSI! version 2 user guide.
diskcomp.exe............This Program is meant to replace DOS's 
			DISKCOMP.COM.
diskcopy.doc............Documentation for DISKCOPY.EXE and DISKCOMP.EXE.
diskcopy.exe............This program is meant to replace DOS' 
			DISKCOPY.COM.
fmtflopt.doc............Documentation for FMTFLOPT.EXE.
fmtflopt.exe............Floptical drive formatter utility, please refer to 
			the RT1000 documentation for more information.
ratat.dsk...............Novell Netware driver V3.11 driver for RT1000A/B.
ratmc.dsk...............RT1000A/B/MC Novell driver V3.11.
read.net................This file.
reados2.doc.............Readme file for RT1000C series boards for OS/2.
rt1000.add..............OS/2 V2.0 driver for RT1000A/B/MC boards.
rt1000a.ugm.............RT1000A board user guide.
rt1000b.ugm.............RT1000B board user guide.
rt1000c.ugm.............RT1000C board user guide.
rt1000mc.ugm............RT1000MC board user guide.
rt1kmcnv.ugm............Novell Netware V3.11 user guide for RT1000MC.
rt1knov.ugm.............Novell Netware V3.11 user guide for RT1000A/B.
rtaspi.doc..............Documentation for RTASPIxx.SYS.
rtaspi10.sys............ASPI Manager for the RT1000 board.
rtaspi1c.cfg............Rancho RT1000 ASPI manager configuration file.
rtaspi1c.doc............Rancho RT1000C ASPI manager guide.
rtaspi1c.sys............Rancho RT1000C ASPI manager.
rtutil.doc..............Documentation file for RTUTIL.EXE
rtutil.exe..............RTBios utility program. RTUTIL contains Low level 
			formatting, and partitioning (similar to FDISK) 
			software. It will also display information about 
			each SCSI device attached to the RT1000.